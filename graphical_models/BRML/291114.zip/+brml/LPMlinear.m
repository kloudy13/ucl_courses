function phi = LPMlinear(x)
phi=x; 