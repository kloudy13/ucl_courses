function [ind val]=argmin(x)
%ARGMIN performs argmin returning the index and value
% [ind val]=argmin(x)
[val ind]=min(x);