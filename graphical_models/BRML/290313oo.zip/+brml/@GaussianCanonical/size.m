function nstates = size(obj)
nstates=obj.table.dim;