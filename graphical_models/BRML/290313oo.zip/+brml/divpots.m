function newpot=divpots(pota,potb)
%DIVPOTS Divide potential pota by potb
% newpot=divpots(pota,potb)
newpot=pota/potb;