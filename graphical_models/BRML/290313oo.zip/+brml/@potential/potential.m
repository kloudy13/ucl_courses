classdef potential
% potential Properties:
% variables
% table
    properties
        variables;
        table;
    end   
end